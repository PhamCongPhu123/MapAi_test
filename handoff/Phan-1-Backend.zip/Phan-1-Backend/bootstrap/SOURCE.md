# Nguồn bàn giao

- Repository nguồn: https://github.com/PhamCongPhu123/MapAi_test
- Nhánh nguồn: `work`
- Commit nguồn: `b75372dc8ffe6b372887dbf0756a18c486dda29e`
- Chỉ xuất file được Git theo dõi; không mang theo `.git`, dependency, database hay kết quả build.
- Lịch sử cũ không được mang vào repo mới vì có cấu hình chứa thông tin bí mật; checkout gốc được giữ nguyên.
- Các commit của người nhận ghi lại việc nhập các nhóm file bàn giao bằng danh tính Git của chính họ. Nguồn tác phẩm vẫn được ghi nhận ở đây.

Các file đã thay cấu hình bí mật hoặc bỏ chuỗi kết nối hard-code:

- `MapAI_BE-main/ListTables.cs`
- `MapAI_BE-main/src/MapAI.API/appsettings.json`
