# Commit 09 — Project iOS, Swift, Xcode và tài nguyên

Thông điệp: `feat(ios): add iOS application project`

Từ checkout Git, copy **nội dung bên trong** thư mục `files/` của nhóm này vào gốc checkout, giữ nguyên cấu trúc đường dẫn. Không copy chính thư mục `files` vào repo. Chỉ thực hiện nhóm này khi nhóm trước đã commit xong.

```sh
git add --pathspec-from-file="../Phan-3-Map-AI-Mobile/commits/09/paths.txt"
git diff --cached --stat
git diff --cached
git commit -m "feat(ios): add iOS application project"
```

Các đường dẫn `../Phan-3-Map-AI-Mobile` giả định bạn giải nén gói bên cạnh checkout. Chỉnh đường dẫn nếu đặt ở nơi khác. Lần đầu cần `git switch main` rồi `git switch -c contrib/map-ai-mobile`; những lần sau tiếp tục chính nhánh đó. Dùng danh tính Git của chính bạn.

## File trong commit này

- `MapAI_FE-feature-map-api/ios/.gitignore`
- `MapAI_FE-feature-map-api/ios/App/App.xcodeproj/project.pbxproj`
- `MapAI_FE-feature-map-api/ios/App/App.xcodeproj/project.xcworkspace/xcshareddata/IDEWorkspaceChecks.plist`
- `MapAI_FE-feature-map-api/ios/App/App/AppDelegate.swift`
- `MapAI_FE-feature-map-api/ios/App/App/Assets.xcassets/AppIcon.appiconset/AppIcon-512@2x.png`
- `MapAI_FE-feature-map-api/ios/App/App/Assets.xcassets/AppIcon.appiconset/Contents.json`
- `MapAI_FE-feature-map-api/ios/App/App/Assets.xcassets/Contents.json`
- `MapAI_FE-feature-map-api/ios/App/App/Assets.xcassets/Splash.imageset/Contents.json`
- `MapAI_FE-feature-map-api/ios/App/App/Assets.xcassets/Splash.imageset/splash-2732x2732-1.png`
- `MapAI_FE-feature-map-api/ios/App/App/Assets.xcassets/Splash.imageset/splash-2732x2732-2.png`
- `MapAI_FE-feature-map-api/ios/App/App/Assets.xcassets/Splash.imageset/splash-2732x2732.png`
- `MapAI_FE-feature-map-api/ios/App/App/Base.lproj/LaunchScreen.storyboard`
- `MapAI_FE-feature-map-api/ios/App/App/Base.lproj/Main.storyboard`
- `MapAI_FE-feature-map-api/ios/App/App/Info.plist`
- `MapAI_FE-feature-map-api/ios/App/App/SceneDelegate.swift`
- `MapAI_FE-feature-map-api/ios/App/CapApp-SPM/.gitignore`
- `MapAI_FE-feature-map-api/ios/App/CapApp-SPM/Package.swift`
- `MapAI_FE-feature-map-api/ios/App/CapApp-SPM/README.md`
- `MapAI_FE-feature-map-api/ios/App/CapApp-SPM/Sources/CapApp-SPM/CapApp-SPM.swift`
- `MapAI_FE-feature-map-api/ios/debug.xcconfig`
