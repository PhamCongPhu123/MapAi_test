# Commit 06 — Unit test frontend và E2E bản đồ/mobile

Thông điệp: `test(map): add map AI and mobile regression coverage`

Từ checkout Git, copy **nội dung bên trong** thư mục `files/` của nhóm này vào gốc checkout, giữ nguyên cấu trúc đường dẫn. Không copy chính thư mục `files` vào repo. Chỉ thực hiện nhóm này khi nhóm trước đã commit xong.

```sh
git add --pathspec-from-file="../Phan-3-Map-AI-Mobile/commits/06/paths.txt"
git diff --cached --stat
git diff --cached
git commit -m "test(map): add map AI and mobile regression coverage"
```

Các đường dẫn `../Phan-3-Map-AI-Mobile` giả định bạn giải nén gói bên cạnh checkout. Chỉnh đường dẫn nếu đặt ở nơi khác. Lần đầu cần `git switch main` rồi `git switch -c contrib/map-ai-mobile`; những lần sau tiếp tục chính nhánh đó. Dùng danh tính Git của chính bạn.

## File trong commit này

- `MapAI_FE-feature-map-api/tests/ai-errors.test.mjs`
- `MapAI_FE-feature-map-api/tests/e2e/map-display.spec.js`
- `MapAI_FE-feature-map-api/tests/e2e/map-tools.spec.js`
- `MapAI_FE-feature-map-api/tests/e2e/mobile.spec.js`
- `MapAI_FE-feature-map-api/tests/map-actions.test.mjs`
- `MapAI_FE-feature-map-api/tests/map-display.test.mjs`
- `MapAI_FE-feature-map-api/tests/mobile.test.mjs`
