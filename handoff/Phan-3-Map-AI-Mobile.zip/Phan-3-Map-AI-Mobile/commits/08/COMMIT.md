# Commit 08 — Project Android, Gradle, manifest và tài nguyên

Thông điệp: `feat(android): add Android application project`

Từ checkout Git, copy **nội dung bên trong** thư mục `files/` của nhóm này vào gốc checkout, giữ nguyên cấu trúc đường dẫn. Không copy chính thư mục `files` vào repo. Chỉ thực hiện nhóm này khi nhóm trước đã commit xong.

```sh
git add --pathspec-from-file="../Phan-3-Map-AI-Mobile/commits/08/paths.txt"
git update-index --chmod=+x -- MapAI_FE-feature-map-api/android/gradlew
git diff --cached --stat
git diff --cached
git commit -m "feat(android): add Android application project"
```

Các đường dẫn `../Phan-3-Map-AI-Mobile` giả định bạn giải nén gói bên cạnh checkout. Chỉnh đường dẫn nếu đặt ở nơi khác. Lần đầu cần `git switch main` rồi `git switch -c contrib/map-ai-mobile`; những lần sau tiếp tục chính nhánh đó. Dùng danh tính Git của chính bạn.

## File trong commit này

- `MapAI_FE-feature-map-api/android/.gitignore`
- `MapAI_FE-feature-map-api/android/app/.gitignore`
- `MapAI_FE-feature-map-api/android/app/build.gradle`
- `MapAI_FE-feature-map-api/android/app/capacitor.build.gradle`
- `MapAI_FE-feature-map-api/android/app/proguard-rules.pro`
- `MapAI_FE-feature-map-api/android/app/src/debug/AndroidManifest.xml`
- `MapAI_FE-feature-map-api/android/app/src/main/AndroidManifest.xml`
- `MapAI_FE-feature-map-api/android/app/src/main/java/vn/mapai/app/MainActivity.java`
- `MapAI_FE-feature-map-api/android/app/src/main/res/drawable-land-hdpi/splash.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/drawable-land-mdpi/splash.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/drawable-land-xhdpi/splash.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/drawable-land-xxhdpi/splash.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/drawable-land-xxxhdpi/splash.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/drawable-port-hdpi/splash.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/drawable-port-mdpi/splash.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/drawable-port-xhdpi/splash.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/drawable-port-xxhdpi/splash.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/drawable-port-xxxhdpi/splash.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/drawable-v24/ic_launcher_foreground.xml`
- `MapAI_FE-feature-map-api/android/app/src/main/res/drawable/ic_launcher_background.xml`
- `MapAI_FE-feature-map-api/android/app/src/main/res/drawable/splash.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/layout/activity_main.xml`
- `MapAI_FE-feature-map-api/android/app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml`
- `MapAI_FE-feature-map-api/android/app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml`
- `MapAI_FE-feature-map-api/android/app/src/main/res/mipmap-hdpi/ic_launcher.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/mipmap-hdpi/ic_launcher_foreground.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/mipmap-hdpi/ic_launcher_round.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/mipmap-mdpi/ic_launcher.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/mipmap-mdpi/ic_launcher_foreground.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/mipmap-mdpi/ic_launcher_round.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/mipmap-xhdpi/ic_launcher.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/mipmap-xhdpi/ic_launcher_foreground.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/mipmap-xhdpi/ic_launcher_round.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/mipmap-xxhdpi/ic_launcher.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/mipmap-xxhdpi/ic_launcher_foreground.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/mipmap-xxhdpi/ic_launcher_round.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/mipmap-xxxhdpi/ic_launcher_foreground.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.png`
- `MapAI_FE-feature-map-api/android/app/src/main/res/values/ic_launcher_background.xml`
- `MapAI_FE-feature-map-api/android/app/src/main/res/values/strings.xml`
- `MapAI_FE-feature-map-api/android/app/src/main/res/values/styles.xml`
- `MapAI_FE-feature-map-api/android/app/src/main/res/xml/file_paths.xml`
- `MapAI_FE-feature-map-api/android/build.gradle`
- `MapAI_FE-feature-map-api/android/capacitor.settings.gradle`
- `MapAI_FE-feature-map-api/android/gradle.properties`
- `MapAI_FE-feature-map-api/android/gradle/wrapper/gradle-wrapper.jar`
- `MapAI_FE-feature-map-api/android/gradle/wrapper/gradle-wrapper.properties`
- `MapAI_FE-feature-map-api/android/gradlew`
- `MapAI_FE-feature-map-api/android/gradlew.bat`
- `MapAI_FE-feature-map-api/android/settings.gradle`
- `MapAI_FE-feature-map-api/android/variables.gradle`
