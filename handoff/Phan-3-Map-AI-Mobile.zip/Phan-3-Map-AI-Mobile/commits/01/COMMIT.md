# Commit 01 — Nguồn bản đồ, định vị, tọa độ và API bản đồ

Thông điệp: `feat(map): add basemap location and coordinate utilities`

Từ checkout Git, copy **nội dung bên trong** thư mục `files/` của nhóm này vào gốc checkout, giữ nguyên cấu trúc đường dẫn. Không copy chính thư mục `files` vào repo. Chỉ thực hiện nhóm này khi nhóm trước đã commit xong.

```sh
git add --pathspec-from-file="../Phan-3-Map-AI-Mobile/commits/01/paths.txt"
git diff --cached --stat
git diff --cached
git commit -m "feat(map): add basemap location and coordinate utilities"
```

Các đường dẫn `../Phan-3-Map-AI-Mobile` giả định bạn giải nén gói bên cạnh checkout. Chỉnh đường dẫn nếu đặt ở nơi khác. Lần đầu cần `git switch main` rồi `git switch -c contrib/map-ai-mobile`; những lần sau tiếp tục chính nhánh đó. Dùng danh tính Git của chính bạn.

## File trong commit này

- `MapAI_FE-feature-map-api/MAP_AND_LOCATION.md`
- `MapAI_FE-feature-map-api/map.md`
- `MapAI_FE-feature-map-api/src/mocks/dragonBridgeMock.js`
- `MapAI_FE-feature-map-api/src/services/deviceLocation.js`
- `MapAI_FE-feature-map-api/src/services/locationProvider.js`
- `MapAI_FE-feature-map-api/src/services/mapBasemap.js`
- `MapAI_FE-feature-map-api/src/services/mapServices.js`
- `MapAI_FE-feature-map-api/src/utils/mapCoordinates.js`
- `MapAI_FE-feature-map-api/src/utils/mapPopup.js`
