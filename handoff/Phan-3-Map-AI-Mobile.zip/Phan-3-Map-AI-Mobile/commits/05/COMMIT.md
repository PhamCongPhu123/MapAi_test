# Commit 05 — Client AI, prompt, xử lý hành động và lỗi AI

Thông điệp: `feat(ai-ui): add map assistant actions and provider errors`

Từ checkout Git, copy **nội dung bên trong** thư mục `files/` của nhóm này vào gốc checkout, giữ nguyên cấu trúc đường dẫn. Không copy chính thư mục `files` vào repo. Chỉ thực hiện nhóm này khi nhóm trước đã commit xong.

```sh
git add --pathspec-from-file="../Phan-3-Map-AI-Mobile/commits/05/paths.txt"
git diff --cached --stat
git diff --cached
git commit -m "feat(ai-ui): add map assistant actions and provider errors"
```

Các đường dẫn `../Phan-3-Map-AI-Mobile` giả định bạn giải nén gói bên cạnh checkout. Chỉnh đường dẫn nếu đặt ở nơi khác. Lần đầu cần `git switch main` rồi `git switch -c contrib/map-ai-mobile`; những lần sau tiếp tục chính nhánh đó. Dùng danh tính Git của chính bạn.

## File trong commit này

- `MapAI_FE-feature-map-api/src/prompts/assistantPrompt.js`
- `MapAI_FE-feature-map-api/src/prompts/mapAssistantPrompt.js`
- `MapAI_FE-feature-map-api/src/services/aiErrors.js`
- `MapAI_FE-feature-map-api/src/services/aiService.js`
- `MapAI_FE-feature-map-api/src/services/mapTools.js`
- `MapAI_FE-feature-map-api/src/utils/executeMapAction.js`
