# Commit 03 — Tìm kiếm, chỉ đường và chi tiết địa điểm

Thông điệp: `feat(map-ui): add search directions and place details`

Từ checkout Git, copy **nội dung bên trong** thư mục `files/` của nhóm này vào gốc checkout, giữ nguyên cấu trúc đường dẫn. Không copy chính thư mục `files` vào repo. Chỉ thực hiện nhóm này khi nhóm trước đã commit xong.

```sh
git add --pathspec-from-file="../Phan-3-Map-AI-Mobile/commits/03/paths.txt"
git diff --cached --stat
git diff --cached
git commit -m "feat(map-ui): add search directions and place details"
```

Các đường dẫn `../Phan-3-Map-AI-Mobile` giả định bạn giải nén gói bên cạnh checkout. Chỉnh đường dẫn nếu đặt ở nơi khác. Lần đầu cần `git switch main` rồi `git switch -c contrib/map-ai-mobile`; những lần sau tiếp tục chính nhánh đó. Dùng danh tính Git của chính bạn.

## File trong commit này

- `MapAI_FE-feature-map-api/src/components/DirectionsPanel.jsx`
- `MapAI_FE-feature-map-api/src/components/PlaceDetailPanel.jsx`
- `MapAI_FE-feature-map-api/src/components/SearchBar.jsx`
- `MapAI_FE-feature-map-api/src/components/SearchSuggestions.jsx`
