# Commit 07 — Capacitor, deep link, điều hướng, script và hướng dẫn mobile

Thông điệp: `feat(mobile): add Capacitor native bridge and mobile tooling`

Từ checkout Git, copy **nội dung bên trong** thư mục `files/` của nhóm này vào gốc checkout, giữ nguyên cấu trúc đường dẫn. Không copy chính thư mục `files` vào repo. Chỉ thực hiện nhóm này khi nhóm trước đã commit xong.

```sh
git add --pathspec-from-file="../Phan-3-Map-AI-Mobile/commits/07/paths.txt"
git diff --cached --stat
git diff --cached
git commit -m "feat(mobile): add Capacitor native bridge and mobile tooling"
```

Các đường dẫn `../Phan-3-Map-AI-Mobile` giả định bạn giải nén gói bên cạnh checkout. Chỉnh đường dẫn nếu đặt ở nơi khác. Lần đầu cần `git switch main` rồi `git switch -c contrib/map-ai-mobile`; những lần sau tiếp tục chính nhánh đó. Dùng danh tính Git của chính bạn.

## File trong commit này

- `MapAI_FE-feature-map-api/.env.mobile-development.example`
- `MapAI_FE-feature-map-api/.env.mobile.example`
- `MapAI_FE-feature-map-api/MOBILE.md`
- `MapAI_FE-feature-map-api/capacitor.config.ts`
- `MapAI_FE-feature-map-api/scripts/mobile-config.mjs`
- `MapAI_FE-feature-map-api/scripts/mobile.mjs`
- `MapAI_FE-feature-map-api/src/components/MobileNavigation.jsx`
- `MapAI_FE-feature-map-api/src/components/NativeAppBridge.jsx`
- `MapAI_FE-feature-map-api/src/config/platform.js`
- `MapAI_FE-feature-map-api/src/utils/nativeNavigation.js`
