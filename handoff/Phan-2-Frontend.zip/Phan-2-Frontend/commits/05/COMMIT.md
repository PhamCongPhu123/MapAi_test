# Commit 05 — Góp ý địa điểm, đánh giá và client địa điểm

Thông điệp: `feat(community-ui): add contributions and location reviews`

Từ checkout Git, copy **nội dung bên trong** thư mục `files/` của nhóm này vào gốc checkout, giữ nguyên cấu trúc đường dẫn. Không copy chính thư mục `files` vào repo. Chỉ thực hiện nhóm này khi nhóm trước đã commit xong.

```sh
git add --pathspec-from-file="../Phan-2-Frontend/commits/05/paths.txt"
git diff --cached --stat
git diff --cached
git commit -m "feat(community-ui): add contributions and location reviews"
```

Các đường dẫn `../Phan-2-Frontend` giả định bạn giải nén gói bên cạnh checkout. Chỉnh đường dẫn nếu đặt ở nơi khác. Lần đầu cần `git switch main` rồi `git switch -c contrib/frontend`; những lần sau tiếp tục chính nhánh đó. Dùng danh tính Git của chính bạn.

## File trong commit này

- `MapAI_FE-feature-map-api/src/components/Community/ContributionDialog.jsx`
- `MapAI_FE-feature-map-api/src/components/Community/ContributionList.jsx`
- `MapAI_FE-feature-map-api/src/components/Community/LocationReviews.jsx`
- `MapAI_FE-feature-map-api/src/services/communityService.js`
- `MapAI_FE-feature-map-api/src/services/locationService.js`
