# Commit 03 — Đăng nhập, đăng ký, xác thực email, khôi phục mật khẩu

Thông điệp: `feat(auth-ui): add account and password recovery flows`

Từ checkout Git, copy **nội dung bên trong** thư mục `files/` của nhóm này vào gốc checkout, giữ nguyên cấu trúc đường dẫn. Không copy chính thư mục `files` vào repo. Chỉ thực hiện nhóm này khi nhóm trước đã commit xong.

```sh
git add --pathspec-from-file="../Phan-2-Frontend/commits/03/paths.txt"
git diff --cached --stat
git diff --cached
git commit -m "feat(auth-ui): add account and password recovery flows"
```

Các đường dẫn `../Phan-2-Frontend` giả định bạn giải nén gói bên cạnh checkout. Chỉnh đường dẫn nếu đặt ở nơi khác. Lần đầu cần `git switch main` rồi `git switch -c contrib/frontend`; những lần sau tiếp tục chính nhánh đó. Dùng danh tính Git của chính bạn.

## File trong commit này

- `MapAI_FE-feature-map-api/src/components/ProtectedRoute.jsx`
- `MapAI_FE-feature-map-api/src/context/AuthContext.jsx`
- `MapAI_FE-feature-map-api/src/context/authContext.js`
- `MapAI_FE-feature-map-api/src/hooks/useAuth.js`
- `MapAI_FE-feature-map-api/src/pages/ForgotPassword.jsx`
- `MapAI_FE-feature-map-api/src/pages/Login.jsx`
- `MapAI_FE-feature-map-api/src/pages/Register.jsx`
- `MapAI_FE-feature-map-api/src/pages/ResetPassword.jsx`
- `MapAI_FE-feature-map-api/src/pages/VerifyEmail.jsx`
- `MapAI_FE-feature-map-api/src/services/authService.js`
- `MapAI_FE-feature-map-api/src/services/userService.js`
- `MapAI_FE-feature-map-api/src/utils/validators.js`
