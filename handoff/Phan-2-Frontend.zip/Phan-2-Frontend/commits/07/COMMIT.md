# Commit 07 — Tài liệu frontend và file môi trường mẫu

Thông điệp: `docs(frontend): document web development workflow`

Từ checkout Git, copy **nội dung bên trong** thư mục `files/` của nhóm này vào gốc checkout, giữ nguyên cấu trúc đường dẫn. Không copy chính thư mục `files` vào repo. Chỉ thực hiện nhóm này khi nhóm trước đã commit xong.

```sh
git add --pathspec-from-file="../Phan-2-Frontend/commits/07/paths.txt"
git diff --cached --stat
git diff --cached
git commit -m "docs(frontend): document web development workflow"
```

Các đường dẫn `../Phan-2-Frontend` giả định bạn giải nén gói bên cạnh checkout. Chỉnh đường dẫn nếu đặt ở nơi khác. Lần đầu cần `git switch main` rồi `git switch -c contrib/frontend`; những lần sau tiếp tục chính nhánh đó. Dùng danh tính Git của chính bạn.

## File trong commit này

- `MapAI_FE-feature-map-api/.env.example`
- `MapAI_FE-feature-map-api/Frontend_Documentation.md`
- `MapAI_FE-feature-map-api/README.md`
